## This package is not working properly.

TERMUX_PKG_MAINTAINER="@termux"

TERMUX_PKG_HOMEPAGE=http://eterm.org/
TERMUX_PKG_DESCRIPTION="A vt102 terminal emulator intended as a replacement for xterm."
TERMUX_PKG_VERSION=0.9.6
TERMUX_PKG_SRCURL=http://eterm.org/download/Eterm-${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_SHA256=72b907aa64f8bcf053f2ecbc8a2e243c6de353a94ecaf579ff2c4e3ae5d7e13c

## TODO: fill this
#TERMUX_PKG_DEPENDS="libast"
