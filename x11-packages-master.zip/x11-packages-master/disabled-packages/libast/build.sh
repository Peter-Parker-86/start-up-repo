## Dependency for Eterm

TERMUX_PKG_MAINTAINER="@termux"

TERMUX_PKG_HOMEPAGE=http://eterm.sourceforge.net
TERMUX_PKG_DESCRIPTION="The Library of Assorted Spiffy Things."
TERMUX_PKG_VERSION=0.7
TERMUX_PKG_SRCURL=http://www.eterm.org/download/libast-${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_SHA256=52055cc0df0af58adc8c43cce6c9a2fff71c627a6bb0395073d353920dd1ebf0

## TODO: fill this
#TERMUX_PKG_DEPENDS=""
