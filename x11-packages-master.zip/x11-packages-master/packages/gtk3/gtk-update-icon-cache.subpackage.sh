TERMUX_SUBPKG_INCLUDE="
bin/gtk-update-icon-cache
share/man/man1/gtk-update-icon-cache.1
"

TERMUX_SUBPKG_DEPENDS="glib, gdk-pixbuf, libandroid-shmem"
TERMUX_SUBPKG_DESCRIPTION="GTK+ icon cache updater"
