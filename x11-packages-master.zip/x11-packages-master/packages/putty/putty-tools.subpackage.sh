TERMUX_SUBPKG_INCLUDE="
bin/plink
bin/pscp
bin/psftp
bin/psusan
bin/puttygen
share/man/man1/plink.1.gz
share/man/man1/pscp.1.gz
share/man/man1/psftp.1.gz
share/man/man1/psusan.1.gz
share/man/man1/puttygen.1.gz
"
TERMUX_SUBPKG_DESCRIPTION="Command-line tools from the PuTTY suite"
TERMUX_SUBPKG_DEPENDS="libandroid-glob"
TERMUX_SUBPKG_DEPEND_ON_PARENT=no
