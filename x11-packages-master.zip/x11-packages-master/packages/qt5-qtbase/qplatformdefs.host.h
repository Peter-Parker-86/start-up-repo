#include "../android-clang/qplatformdefs.h"
#define fseeko64 fseeko
#define ftello64 ftello
#define fopen64 fopen
