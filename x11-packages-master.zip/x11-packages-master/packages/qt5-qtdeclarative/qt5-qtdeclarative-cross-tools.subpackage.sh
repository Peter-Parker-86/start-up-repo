TERMUX_SUBPKG_DESCRIPTION="Qt declarative module for cross build (NOT for Termux)"
TERMUX_SUBPKG_DEPENDS="qt5-qtdeclarative"
TERMUX_SUBPKG_INCLUDE="
opt/qt/cross/*
"
