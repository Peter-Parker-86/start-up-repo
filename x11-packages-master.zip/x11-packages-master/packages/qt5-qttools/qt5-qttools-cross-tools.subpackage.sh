TERMUX_SUBPKG_DESCRIPTION="Tools from qttools module for cross build on the host machine"
TERMUX_SUBPKG_DEPENDS="qt5-qttools"
TERMUX_SUBPKG_INCLUDE="
opt/qt/cross/bin/*
opt/qt/cross/lib/*
"
